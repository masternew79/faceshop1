CREATE PROCEDURE GetAllProduct()
  BEGIN
	SELECT * from product;
END;
